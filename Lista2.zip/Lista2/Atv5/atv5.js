var peso = prompt("Digite seu peso")
var altura = prompt("Digite sua altura")
let IMC

IMC = (peso / altura * altura)

alert = ("Seu IMC é de:" + IMC)