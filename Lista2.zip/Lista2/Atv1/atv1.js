var numeroUm = prompt("Digite o primiero numero")
var numeroDois = prompt("Digite o segundo numero")
let multiplicacao

multiplicacao = numeroUm * numeroDois
alert("O resultado da multiplicação é: "+ multiplicacao)
