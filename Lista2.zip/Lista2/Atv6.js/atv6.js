var plastico = prompt("Quantos quilos de plástico você deseja entregar?")
var papel = prompt("Quantos quilos de papel você deseja entregar?")
var metal = prompt("Quantos quilos de metal você deseja entregar?")

var pagamentoPlastico = (plastico / 10) * 2
var pagamentoPapel = (papel / 30) * 3
var pagamentoMetal = (metal / 50) * 5

var total = pagamentoPlastico + pagamentoPapel + pagamentoMetal

alert("O total a ser pago é R$" + total)
