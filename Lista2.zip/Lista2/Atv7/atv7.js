var totalChopp = prompt("Quantidade total de chopp comprada (em litros): ")
var choppDesperdicado = prompt("Quantidade de chopp desperdiçado (em litros): ")
var choppSobrando = prompt("Quantidade de chopp sobrando (em litros): ")

var choppConsumido = totalChopp - choppDesperdicado - choppSobrando
var pessoas = 45
var mediaPorPessoa = choppConsumido / pessoas

alert("A média de litros bebidos por pessoa é: " + mediaPorPessoa + " litros")
