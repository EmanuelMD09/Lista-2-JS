var anoNascimento = prompt("Digite o ano do seu nascimento (YYYY):")
var anoAtual = prompt("Digite o ano atual (YYYY):")

var idadeAnos = anoAtual - anoNascimento

var meses = (anoAtual - anoNascimento) * 12

var dias = idadeAnos * 365

var semanas = idadeAnos * 52

alert("Sua idade é: " + idadeAnos + " anos");
alert("Isso equivale a aproximadamente " + meses + " meses")
alert("Isso equivale a aproximadamente " + dias + " dias")
alert("Isso equivale a aproximadamente " + semanas + " semanas")
