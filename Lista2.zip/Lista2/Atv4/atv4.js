var totalEleitores = prompt("Digite o número total de eleitores:")
var votosCandidatoX = prompt("Digite o número de votos do candidato X:")
var votosCandidatoY = prompt("Digite o número de votos do candidato Y:")
var votosBrancos = prompt("Digite o total de votos brancos:")
var votosNulos = prompt("Digite o total de votos nulos:")

var percentualCandidatoX = (votosCandidatoX / totalEleitores) * 100
var percentualCandidatoY = (votosCandidatoY / totalEleitores) * 100
var percentualBrancos = (votosBrancos / totalEleitores) * 100
var percentualNulos = (votosNulos / totalEleitores) * 100

alert("Percentual de votos do candidato X: " + percentualCandidatoX + "%")
alert("Percentual de votos do candidato Y: " + percentualCandidatoY + "%")
alert("Percentual de votos brancos: " + percentualBrancos + "%")
alert("Percentual de votos nulos: " + percentualNulos + "%")
