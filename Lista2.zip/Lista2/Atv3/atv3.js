var temperaturaCelcius = prompt("Digite a temperatura em graus Celcius")

conversao = (temperaturaCelcius * (9/5)) + 32

alert = ("O valor de"+ temperaturaCelcius +"em Fahrenheit é:"+ conversao)